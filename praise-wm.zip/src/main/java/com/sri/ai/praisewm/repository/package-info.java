/** CRUD layer for the data model. */
package com.sri.ai.praisewm.repository;
