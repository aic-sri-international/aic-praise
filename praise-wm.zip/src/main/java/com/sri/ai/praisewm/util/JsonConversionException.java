package com.sri.ai.praisewm.util;

/** JsonConversionException. */
class JsonConversionException extends RuntimeException {

  JsonConversionException(String message, Throwable cause) {
    super(message, cause);
  }
}
