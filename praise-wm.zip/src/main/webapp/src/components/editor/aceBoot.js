/* eslint-disable */
import ace from 'ACE_BUILDS/src-noconflict/ace';
import 'ACE_BUILDS/webpack-resolver';
import 'ACE_BUILDS/src-noconflict/mode-javascript';
import 'ACE_BUILDS/src-noconflict/mode-hogm';

export default ace;