ace.define("ace/snippets/glsl",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "glsl";

});
                (function() {
                    ace.require(["ace/snippets/glsl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            