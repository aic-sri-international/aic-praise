To get the current version of the praise jar
--------------------------------------------

    git clone https://github.com/aic-sri-international/aic-praise.git
    mvn package
    copy ...-jar-with-dependencies.jar into this directory